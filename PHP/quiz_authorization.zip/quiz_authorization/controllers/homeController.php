<?php
    include "utils/loggedInOnly.php";
    include "models/homeModel.php";
    include "views/homeView.php";
?>