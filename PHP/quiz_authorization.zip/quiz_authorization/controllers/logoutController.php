<?php
    include "models/logoutModel.php";
?>