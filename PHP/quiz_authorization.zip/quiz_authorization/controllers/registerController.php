<?php
    include "models/registerModel.php";
    include "views/registerView.php"
?>