<?php
require_once "utils/loggedInOnly.php";
require_once "utils/autoload.php";
include "models/addProductModel.php"
?>